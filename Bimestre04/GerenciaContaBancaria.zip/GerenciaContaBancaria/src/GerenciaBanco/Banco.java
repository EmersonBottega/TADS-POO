package GerenciaBanco;

public class Banco {

    public static class Conta {
        private int id;
        private String titular;
        private double saldo;

        // Construtor para inicializar a conta
        public Conta(int id, String titular, double saldoInicial) {
            this.id = id;
            this.titular = titular;
            this.saldo = saldoInicial;
        }

        // Método para depositar
        public void depositar(double valor) {
            if (valor > 0) {
                saldo += valor;
                System.out.println("Depósito de R$ " + valor + " realizado com sucesso.");
            } else {
                System.out.println("Valor de depósito inválido.");
            }
        }

        // Método para sacar
        public void sacar(double valor) {
            if (valor <= saldo) {
                saldo -= valor;
                System.out.println("Saque de R$ " + valor + " realizado com sucesso.");
            } else {
                System.out.println("Erro: Saldo insuficiente.");
            }
        }

        // Método para exibir os detalhes da conta
        public void exibirDetalhes() {
            System.out.println("ID da Conta: " + id);
            System.out.println("Titular: " + titular);
            System.out.println("Saldo: R$ " + saldo);
            System.out.println("-----------------------------------");
        }
    }

    // Método main para testar as contas
    public static void main(String[] args) {
        Conta conta1 = new Conta(1, "João", 500.0);
        Conta conta2 = new Conta(2, "Maria", 1000.0);
        Conta conta3 = new Conta(3, "Pedro", 1500.0);

        System.out.println("Detalhes iniciais das contas:");
        conta1.exibirDetalhes();
        conta2.exibirDetalhes();
        conta3.exibirDetalhes();

        conta1.depositar(200.0);  
        conta2.sacar(300.0);   
        conta3.sacar(2000.0);     

        System.out.println("Detalhes das contas após as operações:");
        conta1.exibirDetalhes();
        conta2.exibirDetalhes();
        conta3.exibirDetalhes();
    }
}
