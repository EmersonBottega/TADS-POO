package veiculos;

public class Main {
    public static void main(String[] args) {
        // carro
        Veiculo carro = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("O carro está se movendo rapidamente na estrada.");
            }
        };

        // bicicleta
        Veiculo bicicleta = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("A bicicleta está sendo pedalada no parque.");
            }
        };

        // caminhão
        Veiculo caminhao = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("O caminhão está transportando carga pesada.");
            }
        };

        // moto
        Veiculo moto = new Veiculo() {
            @Override
            public void mover() {
                System.out.println("A moto está acelerando pelas ruas da cidade.");
            }
        };

        System.out.println("Simulação de veículos em ação:");
        carro.mover();
        bicicleta.mover();
        caminhao.mover();
        moto.mover();
    }
}
