package veiculos;

public interface Veiculo {
    void mover();
}
