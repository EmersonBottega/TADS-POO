package classesinternas;

public class TesteExtra {
    public static void main(String[] args) {
        // Criar instância da classe Extra
        Extra extra = new Extra();

        // Exibir o valor inicial de total
        extra.info();

        // Realizar operação de soma
        extra.operacao(33);

        // Exibir novamente o valor de total
        extra.info();
    }
}