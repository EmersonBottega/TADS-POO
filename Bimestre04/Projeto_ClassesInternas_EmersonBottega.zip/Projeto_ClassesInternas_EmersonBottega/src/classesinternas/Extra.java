package classesinternas;

public class Extra {
    private int total = 10;

    public void operacao(int v) {
        // Classe interna local
        class Somador {
            public void soma(int v) {
                total += v;
            }
        }
        // Uso da classe interna
        Somador s = new Somador();
        s.soma(v);
    }

    public void info() {
        System.out.println("total = " + total);
    }
}
