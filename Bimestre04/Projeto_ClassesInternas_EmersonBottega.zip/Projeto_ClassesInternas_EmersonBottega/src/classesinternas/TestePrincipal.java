package classesinternas;

public class TestePrincipal {
    public static void main(String[] args) {
        // Criar instância da classe Principal
        Principal principal = new Principal(42);

        // Criar instância da classe interna Aninhada
        Principal.Aninhada aninhada = principal.new Aninhada();

        // Exibir o valor armazenado
        aninhada.exibir();
    }
}