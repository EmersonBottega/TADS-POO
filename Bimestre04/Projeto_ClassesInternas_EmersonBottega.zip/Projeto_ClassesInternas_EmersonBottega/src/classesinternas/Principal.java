package classesinternas;

public class Principal {
    private int valor;

    // Construtor
    public Principal(int valor) {
        this.valor = valor;
    }

    // Classe interna
    public class Aninhada {
        public void exibir() {
            System.out.println("valor = " + valor);
        }
    }
}